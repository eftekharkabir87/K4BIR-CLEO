/**
 * goiadmin.js
 * Itachi vibe dark premium mention reply
 * Author: bullet bhai x ChatGPT
 */

module.exports = {
  config: {
    name: "goiadmin",
    version: "1.1",
    author: "EFTEKHAR KABIR⚡",
    role: 0,
    shortDescription: "Itachi-style dark reply on admin mention",
    longDescription: "Replies with calm, cold, Itachi-vibe dark dialogues when admin is mentioned",
    category: "auto",
    guide: "Auto reply when admin is mentioned"
  },

  onChat: async function ({ event, message }) {
    try {
      // 🔴 PUT YOUR ADMIN IDs HERE
      const ADMIN_IDS = [
        "61585911203262", // replace with real UID
        "61585911203262"
      ];

      if (!event.mentions) return;

      const mentionedIDs = Object.keys(event.mentions);
      const isAdminMentioned = mentionedIDs.some(id =>
        ADMIN_IDS.includes(id)
      );

      if (!isAdminMentioned) return;

      // 🩸 Itachi vibe dark dialogues
      const darkDialogues = [
        "🩸 You spoke my name… that already tells me how little you understand.",
        "⚫ Not every silence is weakness. Some are warnings.",
        "🕯️ If you’re looking for answers, you chose the wrong shadow.",
        "🩶 I don’t raise my voice. I raise consequences.",
        "☠️ Names lose their meaning when spoken without purpose.",
        "🖤 You mistook calmness for mercy.",
        "🌑 The darkness you fear is the darkness that protects me.",
        "⚔️ I walk alone, not because I must — but because I choose to.",
        "👁️ Some legends don’t respond. They observe.",
        "🩸 If you mentioned me, be ready to carry the weight of it.",
        "⚫ I’ve already seen how this ends.",
        "🕶️ Power doesn’t announce itself."
      ];

      const reply =
        darkDialogues[Math.floor(Math.random() * darkDialogues.length)];

      return message.reply(reply);
    } catch (err) {
      console.error("goiadmin.js error:", err);
    }
  }
};
