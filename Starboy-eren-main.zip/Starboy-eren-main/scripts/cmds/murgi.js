const delay = (ms) => new Promise(res => setTimeout(res, ms));

// active loop storage
const activeMurgi = new Map();

module.exports = {
  config: {
    name: "murgi",
    version: "1.1.0",
    role: 2,
    author: "Acs kabir",
    description: "Loop bad word messages until stopped",
    category: "fun",
    usages: "@mention | reply | off",
    cooldowns: 5,
  },

  onStart: async function({ message, event, args }) {

    // OFF command
    if (args[0] && args[0].toLowerCase() === "off") {
      if (activeMurgi.has(event.threadID)) {
        activeMurgi.set(event.threadID, false);
        return message.reply("🛑 Murgi mode stopped.");
      } else {
        return message.reply("⚠️ Murgi mode is not running.");
      }
    }

    let targetID, name;

    // ✅ FIXED MENTION GLITCH (mention + reply)
    if (event.mentions && Object.keys(event.mentions).length > 0) {
      targetID = Object.keys(event.mentions)[0];
      name = event.mentions[targetID];
    } 
    else if (event.messageReply) {
      targetID = event.messageReply.senderID;
      name = event.messageReply.senderName || "User";
    } 
    else {
      return message.reply("Please @mention or reply to a target first!");
    }

    const arraytag = [{ id: targetID, tag: name }];

    const messages = [
      "খা*নকির পোলা রেডি তো চু*দা খাওয়ার জন্য 😈 ",
      "এখন তোর মার দুধ দরে ঘুমামু সকালে তোর বাপরে পুকটি মারতে জামু গুড নাইট ছোট 😚",
      "শুন খানকির পোলা ইডেট করতে করতে মইরা যা পোস্ট কইরা ফেমাস কর আমারে, 🙄",
      "গালাগালি করতে করতে তোর বুরি মারে সস্তা বানিয়ে ফেলছস",
      "এই ইহুদির পুত এসব ছাড়া খানকির পোলা কি পারছ",
      "─────কানা তোর মার কালা পুশির যে গন্ধ তুই এটা দিয়ে কিভাবে বের হইলি শালা আবার ডুকে যা 🤣",
      "─────তোর আব্বুর এর নাম নিয়ে আর কতো চলবি গরিবের বাচ্চা🤣",
      "─────ফকিন্নির পোলা টিনের ঘরের মুচি🤣",
      "─────তোর মার মতো বেড়ি আমার ধনের গোড়ার বাল কাটতে রাখি জানু বেগম এর এ যোগ্যতা ও নাই🤣",
      "তর মারে ১২ মাস চুদে গেলেও ওর ভোদার কিছু হবে না কারন মাগি তো ভোদা লোহা বানায় দিছে 😹💥🦶",
      "────তোর মারে চুইদা জীবনের সবচাইতে বড় ভুল করছিলাম আর এই ভুলের সাথে এখন পেতে হচ্ছে। তোর মত নাস্তিক জন্ম হইয়া। 🙂😝",
      "️️️️️⎯⎯খানকির পোলা সিন না দিলে তোর মার বোদা কামড়ায়া খেয়ে ফেলবো। 😂😦",
      "—♡শেষ নিশ্বাস পর্যন্ত আপনার মাকে চুদতে  চাই কি বলেন আপনি-!! >♡🩷🙂🫶",
      "নডির পুত সময় থাকতে ভালো হো খানকির পোলা ফেরাউনের বাচ্চা গালাগালি করা সভাব হয়ে গেছে চুইদ্দা কিন্তু মাইরা লামু",
      " তোর মারে নিয়ে কালকো পোস্ট দিমু🤡",
      " নডির পুত সময় থাকতে ভালো হো খানকির পোলা ফেরাউনের বাচ্চা গালাগালি করা সভাব হয়ে গেছে চুইদ্দা কিন্তু মাইরা লামু",
      " তোর লেংটা মায়রে বিলাইয়ের ধো*ন দিয়ে চুদি 🤣🤣😂",
      " ────তোর মারে চুইদা জীবনের সবচাইতে বড় ভুল করছিলাম আর এই ভুলের সাথে এখন পেতে হচ্ছে। তোর মত নাস্তিক জন্ম হইয়া। 🙂😝",
      "✧˖─ তোর মারে চুদি, বরফ শীতল দেশে নিয়ে, মাগির পুত 🥵😹😹 ",
      " তর মারে জনগণের মধ্যে ফালাইয়া চোদবো 😹👋",
      " ______ মাগি পাড়ার ছিঁড়া কন্ডম দিয়ে তোর বোনরে চোদি!-)🤣🤣",
      " তোর মারে পাকিস্তানের সাবেক প্রেসিডেন্ট ট্রাম্প প্রশাসন সেজে চুদি",
      "শীতের কম্পলের তোলে ফালাইয়া তোর মায়রে ধ!র্ষণ করবো উজানী মা!গীর পোলা",
      " তোর মায়রে উড়ন্ত ✈️বিমানে 💤ঘুমন্ত অবস্থায় লেংটা করে সুদী",
      " ─── এই কাইল্লা ফাডা খামকির ছেলে আমার ১২ ইঞ্চি ধন দিয়া এমন বাড়ি দিমু তর বাবার নাম ভুলে যাবি খনিকের পোলা",
      " নাস্তিক।🦶😹 _____ তোর বোনের ভোদায় ওয়াক থু নডির বাচ্চা",
      " ⎯⎯⎯ এ নাস্তিক মাগির পোলা তোর মারে হিন্দু বৌদ্ধ খ্রিস্টান দিয়ে চুদাবো😹✋",
      " তর মারে গুলিস্তানের অলিতে গলিতে চিপায় চাপায় লেংটা করে চুদি 😹",
      " ────তোর মার কপালে জুতা দিয়া পিটাইতে হইবো ওই খানকিমাগী কেন তোরে জন্ম দিলো।🙂😊🎀",
      " ⎯⎯⎯ এ মাগীরপুত তোর মারে ঠাকুরগাঁও নিয়ে ঠাকুর দিয়ে চুদবো!😹✋",
      " কালা ফাডা মাগির পোলা",
      " তর মারে চুদি মাগির পোলা ৩। ফুট 😹👋",
      "___বৈশাখী ঝরের মধ্যে তোর মাকে মাঠে ফেলে চুদিহহহ বান্ধির পুলা-//🌽🐹🍾🧜‍♀️ ",
      " তর মারে কুকুর দিয়ে চুদাবো মাগির পোলা",
      " ️️️️️⎯⎯  তোর মার বোদার মাংস কাইট্টা কুত্তারে খানকির পোলা",
      " ️️️️️⎯⎯ কিরে বান্দির পোলা তুই নাকি হ্যাকার",
      " ️️️️️⎯⎯   কিরে পা চাটা কুত্তা মাগির পুত ?",
      " ___তর মার ভুদায় ডিজেল ডেলে আগুুন লাগিয়া  দূর দিমো মাগির পোলা",
      "😹_____ তোর কচি বোনকে বিয়ে দিবি রেন্ডি মাগির বাচ্চা!👅 ",
    ];

    activeMurgi.set(event.threadID, true);
    message.reply("🔥 Murgi mode started.");

    try {
      while (activeMurgi.get(event.threadID)) {
        for (const msg of messages) {
          if (!activeMurgi.get(event.threadID)) break;

          await delay(2500);
          message.reply({
            body: `${name}\n${msg}`,
            mentions: arraytag
          });
        }
      }
    } catch (err) {
      console.error(err);
      activeMurgi.delete(event.threadID);
      message.reply("Something went wrong!");
    }
  }
};
