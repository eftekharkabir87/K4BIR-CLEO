const { GoatWrapper } = require("fca-saim-x69x");

module.exports = {
  config: {
    name: "slot",
    version: "3.3",
    author: "KABIR4X💫",
    countDown: 5,
    role: 0,
    category: "game",
    description: "Smooth Premium Slot",
    usage: "slot <amount>"
  },

  onStart: async function ({ event, api, usersData, args }) {
    try {
      const userId = event.senderID;
      const bet = parseInt(args[0]);

      if (!bet || bet <= 0) {
        return api.sendMessage(
          "❌ Enter a valid bet.\nExample: slot 1000",
          event.threadID,
          event.messageID
        );
      }

      let userData = await usersData.get(userId);
      if (!userData) {
        userData = { money: 0 };
        await usersData.set(userId, userData);
      }

      let balance = userData.money ?? userData.data?.money ?? 0;

      if (balance < bet) {
        return api.sendMessage(
          `❌ Not enough balance.\nBalance: ${balance}$`,
          event.threadID,
          event.messageID
        );
      }

      balance -= bet;

      const symbols = ["💎", "👑", "🔥", "🍀", "7️⃣", "🪙"];

      const final = [
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)]
      ];

      api.sendMessage(
        "🎰 CASINO ROYAL\n\nSpinning...",
        event.threadID,
        async (err, info) => {

          if (err) return console.log(err);
          const spinMsgID = info.messageID;

          // Smooth fast spin (low lag)
          for (let i = 0; i < 5; i++) {
            const temp = [
              symbols[Math.floor(Math.random() * symbols.length)],
              symbols[Math.floor(Math.random() * symbols.length)],
              symbols[Math.floor(Math.random() * symbols.length)]
            ];

            await new Promise(r => setTimeout(r, 180));

            await api.editMessage(
`🎰 CASINO ROYAL

${temp[0]} | ${temp[1]} | ${temp[2]}`,
              spinMsgID
            );
          }

          let winnings = 0;
          let resultText = "";

          if (final[0] === final[1] && final[1] === final[2]) {
            winnings = bet * 3;
            balance += winnings;
            resultText = `🎉 JACKPOT!\nYou won ${winnings}$`;
          } 
          else if (
            final[0] === final[1] ||
            final[0] === final[2] ||
            final[1] === final[2]
          ) {
            winnings = bet * 2;
            balance += winnings;
            resultText = `🔥 Double Match!\nYou won ${winnings}$`;
          } 
          else {
            resultText = `😢 No match.\nYou lost ${bet}$`;
          }

          // Save balance
          if (userData.data) {
            userData.data.money = balance;
            await usersData.set(userId, userData);
          } else {
            await usersData.set(userId, { money: balance });
          }

          // Instant delete spin message
          await api.unsendMessage(spinMsgID);

          // Send result separately
          return api.sendMessage(
`🎰 SLOT RESULT

${final[0]} | ${final[1]} | ${final[2]}

${resultText}

💰 Balance: ${balance}$`,
            event.threadID
          );
        }
      );

    } catch (err) {
      console.log("Slot error:", err);
      return api.sendMessage("⚠️ Slot error.", event.threadID);
    }
  }
};

const wrapper = new GoatWrapper(module.exports);
wrapper.applyNoPrefix({ allowPrefix: true });